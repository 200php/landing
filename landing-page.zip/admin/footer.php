	</div>
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<p class="text-center">LP-panel v<?=LP_VERSION?> <?=date("Y")?></p>
				</div>
			</div>
		</div>
	</footer>
    <script src="/assets/js/jquery/jquery.min.js"></script>
    <script src="/assets/js/jquery/inputmask.min.js"></script>
    <script src="/assets/js/jquery/jquery.inputmask.min.js"></script>
    <script src="/assets/js/bootstrap/bootstrap.min.js"></script>
	<script src="/assets/js/plugins/plugins.min.js"></script>
    <script src="/assets/js/active.js"></script>
</body>
</html>